//
//  Draw2D.swift
//  Test2D
//
//  Created by Ospite on 26/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit
import Foundation

class Draw2D: UIView {
 
    var timer = Timer()
    
    let contexT = UIGraphicsGetCurrentContext()
    
    var x = 100
    var y = 0
    
    var logic:Logic?
    
    override func draw(_ rect: CGRect) {
        
        
        
        contexT?.setLineWidth(2.0)
        contexT?.setStrokeColor(UIColor.red.cgColor)
        
        let startPoint:CGPoint = CGPoint(x: 20, y: 30)
        
        let endPoint:CGPoint = CGPoint(x: 50, y: 60)
        
        contexT?.move(to: startPoint)
       // logic = Logic(context: contexT!)
        
        logic?.startDraw()
        contexT?.addLine(to: endPoint)
        
        let point:CGPoint = CGPoint(x: 50, y: 200)
        contexT?.addLine(to: point)
        
        contexT?.strokePath()
        
        
        
        contexT?.move(to: CGPoint(x: 150, y: 150))
        contexT?.setStrokeColor(UIColor.blue.cgColor)
        contexT?.addRect(CGRect(x: 150, y: 150, width: 50, height: 100))
        contexT?.strokePath()
        contexT?.addEllipse(in: CGRect(x: 150, y: 150, width: 50, height: 100))
        contexT?.setFillColor(UIColor.green.cgColor)
        contexT?.fillPath()
        contexT?.strokePath()
        
        contexT?.move(to: CGPoint(x: 360, y: 360))
        contexT?.setStrokeColor(UIColor.black.cgColor)
        contexT?.addArc(tangent1End: CGPoint(x: 125, y: 255), tangent2End: CGPoint(x: 410, y: 120), radius: 21)
        contexT?.strokePath()
    }
    
    
    
    
    
}
