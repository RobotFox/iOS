//
//  Logic.swift
//  Test2D
//
//  Created by Ospite on 26/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import Foundation
import UIKit


class Logic: NSObject {
    
    var x = 100.0
    var y = 0.0
    
    let context:CGContext?
    
    var timer = Timer()
    
    
    init(context:CGContext) {
        self.context = context
    }
    
    
    func startDraw()  {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(drawSnake), userInfo: nil, repeats: true)
    }
    
    func drawSnake() {
        context?.translateBy(x: CGFloat(x), y: CGFloat(y))
        y += 1
        context?.strokePath()
    }
    
    
    
    
    
}
