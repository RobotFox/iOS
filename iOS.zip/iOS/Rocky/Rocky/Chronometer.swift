//
//  Chronometer.swift
//  Rocky
//
//  Created by Ospite on 24/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import Foundation

class Chronometer:NSObject {
    
    var chronoTime:String? = nil
    
    var timer = Timer()
    
    var second = 0
    
    var minute = 0
    
    var hour = 0
    
    var sender:SecondViewController?
    
    init(sender:SecondViewController) {
        self.sender = sender
    }
    
    func startChrono() {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(pippo), userInfo: nil, repeats: true)
    }
    
    func stopChrono() {
        timer.invalidate()
        clearChrono()
    }
    
   func pippo() {
        second+=1
        if second>59 {
            minute+=1
            second=0
        }
        if minute>59 {
            minute=0
            hour+=1
        }
        chronoTime = String(format: "%02d:%02d:%02d",hour,minute,second)
        sender?.lblTime.text = chronoTime
    }
    
    func clearChrono() {
        second = 0
        minute = 0
        hour = 0
    }
    
    
}
