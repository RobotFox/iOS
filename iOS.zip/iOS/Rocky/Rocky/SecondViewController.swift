//
//  SecondViewController.swift
//  Rocky
//
//  Created by Ospite on 23/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class SecondViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    let locationManager = CLLocationManager()
    
    var currentLat:Double = 0.0
    var currentLon:Double = 0.0

    @IBOutlet weak var edtLocation: UITextField!
    
    @IBOutlet weak var lblTime: UILabel!
    
    @IBOutlet weak var mkvMap: MKMapView!
    
    @IBOutlet weak var btnStartStop: UIButton!
    
    var isStarted:Bool = false
    
    var idTraining:Int64 = 0
    
    var chrono:Chronometer?
    
    var timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        locationManager.delegate = self
        //TODO inserire accuretezza a seconda della scelta dell'utente
        //locationManager.distanceFilter = kCLLocationAccuracyNearestTenMeters
        //locationManager.desiredAccuracy = kCLLocationAccuracyBest
        //Finish TODO
        edtLocation.text = nil
        lblTime.text = ""
        mkvMap.delegate = self
        chrono = Chronometer(sender: self)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        edtLocation.text = nil
        lblTime.text = ""
        if CLLocationManager.authorizationStatus() == .notDetermined {
            locationManager.requestAlwaysAuthorization()
        }
        
        
        if CLLocationManager.authorizationStatus() == .denied {
            print("Location Services not authorized!!")
        }
            
        else if CLLocationManager.authorizationStatus() == .authorizedAlways
        {
            locationManager.startUpdatingLocation()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Location method
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        currentLat = (manager.location?.coordinate.latitude)!
        currentLon = (manager.location?.coordinate.longitude)!
        print("lat:\(currentLat)")
        print("lon:\(currentLon)")
    }
    
    @IBAction func btnStartStop_TouchUpInside(_ sender: UIButton) {
        
        if (isStarted) && (edtLocation.text!=="") {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd MM yyy"
            let date = Date()
          
            btnStartStop.setTitle("Stop", for: .normal)
            btnStartStop.backgroundColor = UIColor.red
            isStarted = false
            mkvMap.showsUserLocation = true
            mkvMap.userTrackingMode = .follow
            //idTraining = TrainingsDB.instance.addTraining(clocation: edtLocation.text!, cdate: dateFormatter.string(from: date), ctime: "0")!
            TrainingsDB.instance.addPosition(clat: currentLat, clong: currentLon, cid_Training: idTraining)
            chrono?.startChrono()
            
        }
        else{
            btnStartStop.setTitle("Start", for: .normal)
            btnStartStop.backgroundColor = UIColor.orange
            isStarted = true
            mkvMap.userTrackingMode = .none
            locationManager.stopUpdatingLocation()
            chrono?.stopChrono()
        }
        
    }
    
    
    func insertPositions(){
       TrainingsDB.instance.addPosition(clat: currentLat, clong: currentLon, cid_Training: idTraining)
        
    }

}

