//
//  Training.swift
//  Rocky
//
//  Created by Ospite on 23/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import Foundation

class Training {
    
    let id:Int64?
    
    var location:String
    
    var date:String
    
    var time:String
    
    
    init(id:Int64) {
        
        self.id = id
        location = ""
        date = ""
        time = ""
    }
    
    init(id: Int64, location: String, date: String, time: String) {
        
        self.id = id
        self.location = location
        self.date = date
        self.time = time
    }
    
    
    
    
}
