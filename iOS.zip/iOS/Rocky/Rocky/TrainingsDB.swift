//
//  TrainingsDB.swift
//  Rocky
//
//  Created by Ospite on 23/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import Foundation
import SQLite

class TrainingsDB {
    
    static let instance = TrainingsDB()
    
    private let db: Connection?
    
    private let trainings = Table("trainings")
    private let id       = Expression<Int64>("id_Training")
    private let location = Expression<String?>("location")
    private let date     = Expression<String?>("date")
    private let time = Expression<String?>("time")
    
    
    private let positions = Table("positions")
    private let id_Position = Expression<Int64>("id")
    private let lat = Expression<Double?>("lat")
    private let long = Expression<Double?>("long")
    private let id_Training = Expression<Int64>("id_Training")
    
    private init() {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        
        do {
            db = try Connection("\(path)/TrainingsDB.sqlite3")
        }
        catch
        {
            db = nil
            print ("impossibile aprire database")
        }
        
        createTableTraining()
        createTablePosition()
    }
    
    func createTableTraining()
    {
        do {
            try db!.run(trainings.create(ifNotExists: true) { table in
                table.column(id, primaryKey:true)
                table.column(location)
                table.column(date)
                table.column(time)
            })
        }
        catch
        {
            print ("Impossibile creare tabella")
        }
    }
    
    func createTablePosition() {
        do {
            try db!.run(positions.create(ifNotExists: true) { table in
                table.column(id_Position, primaryKey:true)
                table.column(lat)
                table.column(long)
                table.column(id_Training)
            })
        }
        catch
        {
            print ("Impossibile creare tabella")
        }
    }
    
    
    func addTraining(clocation: String, cdate: String, ctime:String) -> Int64? {
        
        do {
            let insert = trainings.insert(location <- clocation, date  <- cdate, time <- ctime)
            
            let id = try db!.run(insert)
            
            return id
        }
        catch
        {
            print ("insert fallito")
            return -1
        }
    }
    
    func addPosition(clat: Double, clong: Double, cid_Training:Int64) -> Int64? {
        
        do {
            let insert = positions.insert(lat <- clat, long  <- clong, id_Training <- cid_Training)
            
            let id = try db!.run(insert)
            
            return id
        }
        catch
        {
            print ("insert fallito")
            return -1
        }
    }
    
    
    func getTrainings() -> [Training] {
        var trainings = [Training]()
        
        do {
            for training in try
                db!.prepare(self.trainings) {
                    trainings.append(Training(id: training[id], location: training[location]!, date: training[date]!, time: training[time]!))
            }
        }
        catch
        {
            print("select fallito")
        }
        
        return trainings
    }
    
    
    func getPositions(cid_Training:Int64) -> [Position] {
        var positions = [Position]()
        
        do {
            for position in try
                db!.prepare(self.positions.filter(id_Training==cid_Training)){
                    positions.append(Position(id: position[id_Position], lat: position[lat]!, long: position[long]!, id_Training: position[id_Training]))
            }
        }
        catch
        {
            print("select fallito")
        }
        
        return positions
    }
    
    
    func deleteTraining(cid: Int64) -> Bool {
        
        do {
            let training = trainings.filter(id == cid)
            let position = positions.filter(id_Training == cid)
            
            
            try db!.run( training.delete() )
            try db!.run(position.delete())
            return true
        }
        catch
        {
            print ("Delete fallito")
            return false
        }
    }
    
    func updateTraining(cid: Int64, newTraining:Training) -> Bool {
        
        let training = trainings.filter(id == cid)
        
        do {
            let update = training.update([location <- newTraining.location, date <- newTraining.date, time <- newTraining.time])
            
            if try db!.run(update) > 0 {
                return true
            }
        }
        catch
        {
            print ("Update error")
        }
        
        return false
    }
}
    
