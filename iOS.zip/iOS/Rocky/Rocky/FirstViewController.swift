//
//  FirstViewController.swift
//  Rocky
//
//  Created by Ospite on 23/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tbvTrainings: UITableView!
    
    var trainings:[Training]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tbvTrainings.delegate = self
        tbvTrainings.dataSource = self
        selectDB()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        selectDB()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //stuff to do
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = trainingCell()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (trainings?.count)!
    }
    
    func selectDB() {
        trainings = TrainingsDB.instance.getTrainings()
    }
    
}

class trainingCell: UITableViewCell {

    @IBOutlet weak var lblLocation: UILabel!
    
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var lblTime: UILabel!
    
}


