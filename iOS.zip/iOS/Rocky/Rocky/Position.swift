//
//  Position.swift
//  Rocky
//
//  Created by Ospite on 23/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import Foundation

class Position{
    
    let id:Int64?
    
    var lat: Double
    
    var long: Double
    
    var id_Training:Int64
    
    
    init(id:Int64) {
        
        self.id = id
        lat = 0.0
        long = 0.0
        id_Training = 0
    }
    
    init(id: Int64, lat: Double, long: Double, id_Training: Int64) {
        
        self.id = id
        self.lat = lat
        self.long = long
        self.id_Training = id_Training
    }

    
    
    
    
    
    
    
}
