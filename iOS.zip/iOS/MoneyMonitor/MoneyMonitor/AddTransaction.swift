//
//  AddTransaction.swift
//  MoneyMonitor
//
//  Created by Ospite on 31/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import Foundation
import UIKit

class AddTransaction : UIViewController {

    @IBOutlet weak var descTransaction: UITextField!
    
    @IBOutlet weak var importTransaction: UITextField!
    
    @IBOutlet weak var typeTransaction: UISegmentedControl!
    
    @IBOutlet weak var dtPickTransaction: UIDatePicker!
    
    @IBOutlet weak var catTransaction: UITextField!
    
override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    dtPickTransaction.backgroundColor = UIColor.white
}

override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
}
    
    @IBAction func btnCancel_TouchUpInside(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnSave_TouchUpInside(_ sender: UIButton) {
        
    }
}
