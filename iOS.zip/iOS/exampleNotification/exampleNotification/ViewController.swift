//
//  ViewController.swift
//  exampleNotification
//
//  Created by Ospite on 06/06/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController, UNUserNotificationCenterDelegate {
    
    var messageSubtitle = "Riunione con lo staff tecnico"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge], completionHandler: {(granted, error) in //Gestione errore
            })
        
        UNUserNotificationCenter.current().delegate = self
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.alert,.sound, .badge])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        switch response.actionIdentifier {
        case "Repeat":
            self.sendNotification()
            
            case "Change":
            let textResponse = response as! UNTextInputNotificationResponse
            messageSubtitle = textResponse.userText
            
            
        default:
            break
        }
        completionHandler()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnSend_TouchUpInside(_ sender: UIButton) {
        
        sendNotification()
        
    }
    
    func sendNotification()  {
        let content = UNMutableNotificationContent()
        content.title = "Notification Riunion"
        content.subtitle = messageSubtitle
        content.body = "Remember to bring cofee!!!"
        content.badge = 1
        
        let repeatAction = UNNotificationAction(identifier: "Repeat", title: "Repeat Notification", options: [])
        
        let changeAction = UNTextInputNotificationAction(identifier: "Change", title: "Change Notification", options: [])
        
        let category = UNNotificationCategory(identifier: "actionCategory", actions: [repeatAction,changeAction], intentIdentifiers: [], options: [])
        content.categoryIdentifier = "actionCategory"
        UNUserNotificationCenter.current().setNotificationCategories([category])
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
        let requestIdentifier = "testNotification"
        let request = UNNotificationRequest(identifier: requestIdentifier, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: {(error) in //gestione errore
        })
        
    }
    
    @IBAction func btnCancel_TouchUpInside(_ sender: UIButton) {
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: ["testNotification"])
        
        UIApplication.shared.applicationIconBadgeNumber = 0
        
    }
    
    
    
    
    
}
