//
//  ViewController.swift
//  DBExample
//
//  Created by Ospite on 16/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var edtName: UITextField!
    
    @IBOutlet weak var edtSurname: UITextField!
    
    @IBOutlet weak var edtPhone: UITextField!
    
    @IBOutlet weak var tbvContacts: UITableView!
    
    private var contacts = [Contact] ()
    
    private var selectContact: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tbvContacts.delegate = self
        tbvContacts.dataSource = self
        contacts = ContactsDB.instance.getContacs()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnAdd_TouchUpInside(_ sender: UIButton) {
        
        if (edtName.text?.isEmpty)! && (edtSurname.text?.isEmpty)! && (edtPhone.text?.isEmpty)! {
            print("Campi vuoti")
        }
        else{
            if letid = Contacts.addContact(surname: surname)
            {
                
            }
            let nameContact = edtName.text ?? ""
            let surnameContact = edtSurname.text ?? ""
            let phoneContact = edtPhone.text ?? ""
            
            let contact = Contact(id: 0, surname: surnameContact, name: nameContact, phone: phoneContact)
            contacts.append(contact)
            
            tbvContacts.insertRows(at: [IndexPath(row: contacts.count-1, section: 0)], with: UITableViewRowAnimation.fade)
            clearLbl()    
        }
        
        
    }
    
    @IBAction func btnUpdate_TouchUpInside(_ sender: UIButton) {
        
        if selectContact != nil {
            let id = contacts[selectContact!].id
            let nameContact = edtName.text ?? ""
            let surnameContact = edtSurname.text ?? ""
            let phoneContact = edtPhone.text ?? ""
            
            let contact = Contact(id: 0, surname: surnameContact, name: nameContact, phone: phoneContact)
            
            contacts.remove(at: selectContact!)
            contacts.insert(contact, at: selectContact!)
            tbvContacts.reloadData()
            clearLbl()
        }
        else{
            print("Nessun record selezionato")
        }
        
        
    }
    
    @IBAction func btnDelete_TouchUpInside(_ sender: UIButton) {
        
        if selectContact != nil {
            contacts.remove(at: selectContact!)
            tbvContacts.reloadData()
            clearLbl()
        }
        else{
            print("Nessun record selezionato")
        }
        
    }
    
    //metodi TableView
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: nil)
        
        cell.detailTextLabel?.text = contacts[indexPath.row].surname + " " + contacts[indexPath.row].name
            
         cell.textLabel?.text = contacts[indexPath.row].phone
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        edtName.text = contacts[indexPath.row].name
        edtSurname.text = contacts[indexPath.row].surname
        edtPhone.text = contacts[indexPath.row].phone
        
        selectContact = indexPath.row
    }
    
    func clearLbl() {
        edtName.text=nil
        edtSurname.text=nil
        edtPhone.text=nil
    }
    

}

