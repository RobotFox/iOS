//
//  ContactsDB.swift
//  DBExample
//
//  Created by Ospite on 16/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import SQLite
import Foundation

class ContactsDB{
    
    static let instance = ContactsDB()
    
    private let db: Connection?
    
    private let contacts = Table("contacts")
    private let id = Expression<Int64>("id")
    private let surname  = Expression<String?>("surname")
    private let name = Expression<String?>("name")
    private let phone = Expression<String?>("phone")
    
    private init() {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        
        
        do {
            db = try Connection("\(path)/ContactsDB.sqlite3")
        }
        catch{
            db = nil
            print("Impossibile aprire database")
        }
        
        createTable()
    }
    
    
    func createTable() {
        do {
            try db.run(contacts.create(ifNotExist: true) { table in
                table.column(id, primaryKey: true)
                table.column(surname)
                table.column(name)
                table.column(phone)
            })
        }
        catch {
            print("Impossibile creare tabella")
        }
    }
    
    func addContact(csurname:String, cname:String, cphone:String) -> Int64 {
        do {
            let insert = contacts.insert(name <- cname, surname <- csurname, phone <- cphone)
            let id = try db.run(insert)
            return id
        }
        catch {
            print("Insert failed")
            return -1
        }
    }
    
    func getContacs() -> [Contact] {
        var contacs = [Contact]
        do {
            for contacts in try db.prepare(self.contacts){
                contacts.append(Contact(id: contact[id], surname: contact[surname], name: contact[nome], phone: comtact[phone]))
                
            }
        }
        catch{
            print("select fallito")
        }
        return contacts
    }
    
    func deleteContact(cid: Int64) -> Bool {
        
        do {
            let  contact = contacts.filter(id==cid)
            try db.run(contact.delete())
            return true
        }
        catch{
            print("Delete fallito")
            return false
        }
    }
    
    func updateContact(cid: Int64, newContact:Contact) -> Bool {
        let contact = contacts.filter(id==cid)
        
        do{
            let update = contact.update([name <- newContact.name, surname <- newContact.surname, phone <- newContact.phone])
            if try db.run(update) > 0 {
                return true
            }
        }
        catch {
            print("Update error")
        }
        return false
    }
    
}
