//
//  Draw2D.swift
//  Graph
//
//  Created by Ospite on 30/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit
import Foundation

class Draw2D: UIView {
    
    var data = [Int]()
    var x = 0.0
    var y = 0.0
    
    override func draw(_ rect: CGRect) {
        
        data = [100,120,10, 50, 300]
        
        let context = UIGraphicsGetCurrentContext()
        
        
        var maxWidth:Double = Double(rect.width)
        
        var maxHeight:Double = Double(rect.height)
        
        var marginX = 10.0
        
        var marginY = 10.0
        
        context?.setLineWidth(4.5)
        context?.setStrokeColor(UIColor.darkGray.cgColor)
        context?.addRect(CGRect(x: 0, y: 0, width: maxWidth, height: maxHeight))
        context?.strokePath()
        
        var startPoint = CGPoint(x: 10, y: 10)
        var finishPoint = CGPoint(x: 10, y: maxHeight-10)
        
        context?.move(to: startPoint)
        context?.addLine(to: finishPoint)
        context?.addLine(to: CGPoint(x: maxWidth-10, y: maxHeight-10))
        context?.strokePath()
        
        
        var passo = (maxWidth-marginX-marginY) / Double(data.count)
        
        var max = data.max()
        
        var k =  (Int(maxHeight-20) / max!)
        
        context?.setFillColor(UIColor.blue.cgColor)
        context?.move(to: finishPoint)
        var pos = Double(finishPoint.x)
        
        for value:Int in data {
            context?.addRect(CGRect(x: CGFloat(pos), y: CGFloat(Int(finishPoint.y)), width: CGFloat(passo), height: CGFloat(value * (-k))))
            pos+=passo
            context?.strokePath()
            
        }
        for value:Int in data {
            context?.addRect(CGRect(x: CGFloat(pos), y: CGFloat(Int(finishPoint.y)), width: CGFloat(passo), height: CGFloat(value * (-k))))
            pos+=passo
            context?.fillPath()
            
        }
        
    }
}
