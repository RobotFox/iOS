//
//  ViewController.swift
//  ExampleGeo
//
//  Created by Ospite on 23/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func test(){
        var currentLocation:CLLocation
        
        var previousLocation:CLLocation
        
        currentLocation.distance(from: previousLocation)
        
        
        
        
        
    }

}

