//
//  ViewController.swift
//  FlagSON
//
//  Created by Ospite on 09/06/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {

    var arrCountry:[String] = []
    
    var arrInitial:[String] = []
    
    var countries:[String:Any] = [:]
    
    var arrImage:[UIImage] = []
    
    
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    @IBOutlet weak var controllerView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        indicator.startAnimating()
        callCountries()
        controllerView.delegate = self
        controllerView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        controllerView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrCountry.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = controllerView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        var imageViewFlag = cell.viewWithTag(1) as! UIImageView
        
        var lblCountry = cell.viewWithTag(2) as! UILabel
        
        lblCountry.text = arrCountry[indexPath.row]
        
        imageViewFlag.image = arrImage[indexPath.row]
        
        return cell
    }
    
    
    func callCountries()  {
        
        let urlString = "http://www.geognos.com/api/en/countries/info/all.json"
        
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error)
            } else {
                do {
                    
                    let parsedData = try JSONSerialization.jsonObject(with: data!) as! [String:Any]
                    let country = parsedData["Results"] as! [String:Any]
                    for (key, value) in country {
                        self.arrInitial.append(key)
                        
                        self.countries = value as! [String:Any]
                     self.arrCountry.append(self.countries["Name"] as! String)
                        print("Sto caricando paesi")
                        print("Paesi array: \(self.arrCountry.count)")
                    }
                    for par in self.arrInitial {
                        let urlString = "http://www.geognos.com/api/en/countries/flag/\(par).png"
                        let url = URL(string: urlString)
                        
                        let data = try? Data(contentsOf: url!)
                        
                        self.arrImage.append(UIImage(data: data!)!)
                        print("Sto caricando bandiere")
                        print("Bandiere array: \(self.arrImage.count)")
                    }
                    
                    self.controllerView.reloadData()
                    self.indicator.stopAnimating()
                } catch let error as NSError {
                    print(error)
                }
            }
            
            }.resume()
    }
}
