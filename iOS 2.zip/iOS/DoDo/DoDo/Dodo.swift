//
//  Dodo.swift
//  DoDo
//
//  Created by Ospite on 17/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import Foundation

class Dodo {
    
    let id:Int64?
    
    var description:String
    
    init(id:Int64) {
        self.id = id
        description = ""
    }
    
    init(id:Int64,description:String) {
        self.id = id
        self.description = description
    }
}
