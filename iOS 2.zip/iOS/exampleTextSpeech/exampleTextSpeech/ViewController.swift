//
//  ViewController.swift
//  exampleTextSpeech
//
//  Created by Ospite on 07/06/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    let speechSynth = AVSpeechSynthesizer()
    
    @IBOutlet weak var pitchSlider: UISlider!
    @IBOutlet weak var rateSlider: UISlider!
    @IBOutlet weak var volumeSlider: UISlider!
    @IBOutlet weak var myTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnSpeech_TouchUp(_ sender: UIButton) {
        
        let speechUtteranc = AVSpeechUtterance(string: myTextView.text)
        speechUtteranc.rate = rateSlider.value
        speechUtteranc.pitchMultiplier = pitchSlider.value
        speechUtteranc.volume = volumeSlider.value
        speechSynth.speak(speechUtteranc)
    }

}

