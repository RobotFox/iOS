//
//  ViewController.swift
//  GeoExample
//
//  Created by Ospite on 19/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    let locationManager = CLLocationManager()
    
    var currentLat:Double = 0.0
    
    var currentLon:Double = 0.0

    @IBOutlet weak var mkView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        locationManager.delegate = self
        locationManager.distanceFilter = kCLLocationAccuracyNearestTenMeters
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        mkView.delegate = self
        mkView.showsUserLocation = true
        mkView.userTrackingMode = .follow
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        if CLLocationManager.authorizationStatus() == .notDetermined {
            locationManager.requestAlwaysAuthorization()
        }
        
        
        if CLLocationManager.authorizationStatus() == .denied {
            print("Location Services not authorized!!")
        }
        
        else if CLLocationManager.authorizationStatus() == .authorizedAlways
        {
            locationManager.startUpdatingLocation()
        }
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Methods of Location
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        currentLat = (manager.location?.coordinate.latitude)!
        currentLon = (manager.location?.coordinate.longitude)!
        print("lat:\(currentLat)")
        print("lon:\(currentLon)")
    }


}

