//
//  ViewController.swift
//  TestUI
//
//  Created by Ospite on 09/06/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    var arrCountry:[String] = ["Italia","Francia","Spagna"]
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        collectionView.delegate = self
        collectionView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrCountry.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        var button = cell.viewWithTag(1) as! UIButton
        
        button.setImage(#imageLiteral(resourceName: "money"), for: .normal)
        
        var label = cell.viewWithTag(2) as! UILabel
        
        label.text = arrCountry[indexPath.row]
    
        return cell
    }

    func callJSON(){
        let urlString = "http://www.geognos.com/api/en/countries/info/all.json"
        
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error)
            } else {
                do {
                    
                    let parsedData = try JSONSerialization.jsonObject(with: data!) as! [String:Any]
                    let country = parsedData["currently"] as! [String:Any]
                    
                    print(country)
                    
                    for (key, value) in currentConditions {
                        print("\(key) - \(value) ")
                    }
                    
                    let currentTemperatureF = currentConditions["temperature"] as! Double
                    print(currentTemperatureF)
                } catch let error as NSError {
                    print(error)
                }
            }
            
            }.resume()
    }
    

}

