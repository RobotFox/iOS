//
//  Transaction.swift
//  MoneyMonitor
//
//  Created by Ospite on 30/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import Foundation


class Transaction {
    
    private let id:Int64?
    private var date:String
    private var description:String
    private var imp:Double
    private var type:Bool
    private var category:Int64
    
    
    init(id:Int64) {
        self.id = id
        date = ""
        description = ""
        imp = 0.0
        type = false
        category = 0
    }
    
    init(id:Int64, date:String, description:String,imp:Double,type:Bool,category:Int64) {
        self.id = id
        self.date = date
        self.description = description
        self.imp = imp
        self.type = type
        self.category = category
    }
    
    
    
}
